<?php $__env->startSection('content'); ?>

    <div style="padding: 30px">
        <h1>Token Criado</h1>

        <div style="font-size: 16pt; color: red; font-weight:bold">
            <span>Atencao: conserve este token num lugar seguro pois nao podera recuperar uma vez fechada a janela!</span>

        </div>

        <div style="margin: 20px 10px 10px;">
            <p>
                <?php echo e($token); ?>

            </p>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Manuela.Chadreque\laravel_Stello\eMazaGameServer\resources\views/displayTokens.blade.php ENDPATH**/ ?>