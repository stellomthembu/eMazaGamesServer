<script src="{{ asset('template/dist/js/main.min.js')}}"></script>
