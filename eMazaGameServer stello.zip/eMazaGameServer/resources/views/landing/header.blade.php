<header class="site-header">
            <div class="container">
                <div class="site-header-inner">
                    <div class="brand header-brand">
                        <h1 class="m-0">
							<a href="#">
								<img
                                class="header-logo-image"
                                src="{{ asset('template/dist/images/logo.png')}}"
                                 alt="Logo"
                                 style="width:15%; height: 15%"
                                 >
                            </a>
                        </h1>
                    </div>
                </div>
            </div>
        </header>
